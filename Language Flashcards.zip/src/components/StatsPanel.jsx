// src/components/StatsPanel.jsx
import React from 'react';
import { BarChart3, Calendar, Clock, TrendingUp, Award } from 'lucide-react';

const StatsPanel = ({ 
  cards, 
  learnedCount, 
  progress, 
  selectedLanguage,
  totalStudyTime = 0 
}) => {
  // Calculate various statistics
  const totalCards = cards.length;
  const remainingCards = totalCards - learnedCount;
  
  const difficultyStats = cards.reduce((acc, card) => {
    acc[card.difficulty] = (acc[card.difficulty] || 0) + 1;
    return acc;
  }, {});

  const learnedByDifficulty = cards.reduce((acc, card) => {
    if (card.learned) {
      acc[card.difficulty] = (acc[card.difficulty] || 0) + 1;
    }
    return acc;
  }, {});

  const formatTime = (minutes) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'hard': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getProgressLevel = (progress) => {
    if (progress >= 90) return { level: 'Expert', icon: '👑', color: 'text-purple-600' };
    if (progress >= 70) return { level: 'Advanced', icon: '🚀', color: 'text-blue-600' };
    if (progress >= 50) return { level: 'Intermediate', icon: '📚', color: 'text-green-600' };
    if (progress >= 25) return { level: 'Beginner', icon: '🌱', color: 'text-yellow-600' };
    return { level: 'Novice', icon: '🔰', color: 'text-gray-600' };
  };

  const currentLevel = getProgressLevel(progress);

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm border">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-900 flex items-center space-x-2">
          <BarChart3 size={24} />
          <span>Study Statistics</span>
        </h2>
        <div className={`flex items-center space-x-2 px-3 py-1 rounded-full ${currentLevel.color} bg-opacity-10`}>
          <span className="text-lg">{currentLevel.icon}</span>
          <span className={`font-medium ${currentLevel.color}`}>{currentLevel.level}</span>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="text-center p-4 bg-blue-50 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">{totalCards}</div>
          <div className="text-sm text-blue-600 font-medium">Total Cards</div>
        </div>
        
        <div className="text-center p-4 bg-green-50 rounded-lg">
          <div className="text-2xl font-bold text-green-600">{learnedCount}</div>
          <div className="text-sm text-green-600 font-medium">Learned</div>
        </div>
        
        <div className="text-center p-4 bg-yellow-50 rounded-lg">
          <div className="text-2xl font-bold text-yellow-600">{remainingCards}</div>
          <div className="text-sm text-yellow-600 font-medium">Remaining</div>
        </div>
        
        <div className="text-center p-4 bg-purple-50 rounded-lg">
          <div className="text-2xl font-bold text-purple-600">{progress}%</div>
          <div className="text-sm text-purple-600 font-medium">Complete</div>
        </div>
      </div>

      {/* Difficulty Breakdown */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-3 flex items-center space-x-2">
          <TrendingUp size={20} />
          <span>Difficulty Breakdown</span>
        </h3>
        
        <div className="space-y-3">
          {Object.entries(difficultyStats).map(([difficulty, count]) => {
            const learned = learnedByDifficulty[difficulty] || 0;
            const percentage = count > 0 ? Math.round((learned / count) * 100) : 0;
            
            return (
              <div key={difficulty} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium capitalize ${getDifficultyColor(difficulty)}`}>
                    {difficulty}
                  </span>
                  <span className="text-sm text-gray-600">
                    {learned}/{count} cards
                  </span>
                </div>
                
                <div className="flex items-center space-x-2">
                  <div className="w-16 bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${
                        difficulty === 'easy' ? 'bg-green-500' :
                        difficulty === 'medium' ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-gray-700 w-10 text-right">
                    {percentage}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Study Insights */}
      <div className="border-t pt-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-3 flex items-center space-x-2">
          <Award size={20} />
          <span>Study Insights</span>
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
            <Calendar className="text-blue-500" size={20} />
            <div>
              <div className="text-sm font-medium text-gray-700">Current Language</div>
              <div className="text-lg font-bold text-gray-900 capitalize">{selectedLanguage}</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
            <Clock className="text-green-500" size={20} />
            <div>
              <div className="text-sm font-medium text-gray-700">Study Time</div>
              <div className="text-lg font-bold text-gray-900">{formatTime(totalStudyTime)}</div>
            </div>
          </div>
        </div>

        {/* Motivational message */}
        <div className="mt-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-100">
          <div className="text-center">
            {progress === 100 ? (
              <p className="text-blue-700 font-medium">🎉 Congratulations! You've mastered all cards in {selectedLanguage}!</p>
            ) : remainingCards <= 5 ? (
              <p className="text-blue-700 font-medium">🔥 You're almost there! Only {remainingCards} cards left to master!</p>
            ) : progress >= 50 ? (
              <p className="text-blue-700 font-medium">💪 Great progress! You're more than halfway through your {selectedLanguage} journey!</p>
            ) : (
              <p className="text-blue-700 font-medium">🌟 Keep going! Every card you learn brings you closer to fluency!</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsPanel;