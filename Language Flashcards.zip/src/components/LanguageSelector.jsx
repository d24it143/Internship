// src/components/LanguageSelector.jsx
import React from 'react';
import { Globe } from 'lucide-react';

const LanguageSelector = ({ selectedLanguage, onLanguageChange, languages }) => {
  const languageFlags = {
    english: '🇺🇸',
    spanish: '🇪🇸',
    french: '🇫🇷',
    german: '🇩🇪'
  };

  const languageNames = {
    english: 'English',
    spanish: 'Español',
    french: 'Français',
    german: 'Deutsch'
  };

  return (
    <div className="flex flex-col space-y-2">
      <label className="flex items-center space-x-2 text-sm font-medium text-gray-700">
        <Globe size={16} />
        <span>Select Language</span>
      </label>
      
      <div className="relative">
        <select
          value={selectedLanguage}
          onChange={(e) => onLanguageChange(e.target.value)}
          className="w-full appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          {languages.map((lang) => (
            <option key={lang} value={lang}>
              {languageFlags[lang]} {languageNames[lang]}
            </option>
          ))}
        </select>
        
        {/* Custom dropdown arrow */}
        <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
          <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </div>

      {/* Language options as buttons (alternative layout) */}
      <div className="hidden sm:flex flex-wrap gap-2 mt-2">
        {languages.map((lang) => (
          <button
            key={lang}
            onClick={() => onLanguageChange(lang)}
            className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              selectedLanguage === lang
                ? 'bg-blue-500 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <span className="text-lg">{languageFlags[lang]}</span>
            <span>{languageNames[lang]}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default LanguageSelector;