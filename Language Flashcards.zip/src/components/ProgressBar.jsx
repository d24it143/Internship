// src/components/ProgressBar.jsx
import React from 'react';
import { Trophy, Target, BookOpen } from 'lucide-react';

const ProgressBar = ({ 
  progress, 
  learnedCount, 
  totalCards, 
  currentCardIndex, 
  showDetailed = true 
}) => {
  const getProgressColor = (progress) => {
    if (progress >= 80) return 'bg-green-500';
    if (progress >= 60) return 'bg-blue-500';
    if (progress >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getProgressText = (progress) => {
    if (progress === 100) return 'Completed! 🎉';
    if (progress >= 80) return 'Almost there! 💪';
    if (progress >= 60) return 'Good progress! 📚';
    if (progress >= 40) return 'Keep going! 🚀';
    return 'Just started! 🌱';
  };

  return (
    <div className="bg-white rounded-lg p-4 shadow-sm border">
      {/* Main progress bar */}
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium text-gray-700">Learning Progress</h3>
        <span className="text-sm font-bold text-gray-900">{progress}%</span>
      </div>
      
      <div className="w-full bg-gray-200 rounded-full h-3 mb-3">
        <div 
          className={`h-3 rounded-full transition-all duration-500 ${getProgressColor(progress)}`}
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Progress text */}
      <div className="text-center text-sm text-gray-600 mb-3">
        {getProgressText(progress)}
      </div>

      {/* Detailed stats */}
      {showDetailed && (
        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="flex flex-col items-center space-y-1">
            <div className="flex items-center space-x-1 text-green-600">
              <Trophy size={16} />
              <span className="text-sm font-medium">Learned</span>
            </div>
            <span className="text-lg font-bold text-green-600">{learnedCount}</span>
          </div>
          
          <div className="flex flex-col items-center space-y-1">
            <div className="flex items-center space-x-1 text-blue-600">
              <BookOpen size={16} />
              <span className="text-sm font-medium">Total</span>
            </div>
            <span className="text-lg font-bold text-blue-600">{totalCards}</span>
          </div>
          
          <div className="flex flex-col items-center space-y-1">
            <div className="flex items-center space-x-1 text-purple-600">
              <Target size={16} />
              <span className="text-sm font-medium">Current</span>
            </div>
            <span className="text-lg font-bold text-purple-600">{currentCardIndex + 1}</span>
          </div>
        </div>
      )}

      {/* Achievement badges */}
      {progress === 100 && (
        <div className="mt-4 text-center">
          <div className="inline-flex items-center space-x-2 bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
            <Trophy size={16} />
            <span>Language Master!</span>
          </div>
        </div>
      )}
      
      {progress >= 50 && progress < 100 && (
        <div className="mt-4 text-center">
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
            <Target size={16} />
            <span>Halfway Hero!</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProgressBar;