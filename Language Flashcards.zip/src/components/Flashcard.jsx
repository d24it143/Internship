// src/components/Flashcard.jsx
import React from 'react';
import { RotateCcw, CheckCircle, XCircle } from 'lucide-react';

const Flashcard = ({ 
  card, 
  isFlipped, 
  onFlip, 
  onMarkLearned,
  showActions = true 
}) => {
  if (!card) {
    return (
      <div className="w-full max-w-md mx-auto bg-gray-100 rounded-xl p-8 text-center text-gray-500">
        No cards available
      </div>
    );
  }

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Card */}
      <div 
        className={`relative w-full h-64 cursor-pointer transition-all duration-300 transform hover:scale-105 ${
          isFlipped ? 'rotate-y-180' : ''
        }`}
        onClick={onFlip}
        style={{ transformStyle: 'preserve-3d' }}
      >
        {/* Front of card */}
        <div 
          className={`absolute inset-0 w-full h-full rounded-xl shadow-lg bg-gradient-to-br from-blue-500 to-purple-600 text-white flex flex-col justify-center items-center p-6 ${
            isFlipped ? 'opacity-0 rotate-y-180' : 'opacity-100'
          }`}
          style={{ 
            backfaceVisibility: 'hidden',
            transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)'
          }}
        >
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">{card.front}</h2>
            <div className="flex items-center justify-center space-x-2 text-sm opacity-75">
              <RotateCcw size={16} />
              <span>Click to flip</span>
            </div>
          </div>
          
          {/* Difficulty badge */}
          <div className={`absolute top-4 right-4 px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(card.difficulty)}`}>
            {card.difficulty}
          </div>
          
          {/* Learned indicator */}
          {card.learned && (
            <div className="absolute top-4 left-4 bg-green-500 text-white rounded-full p-1">
              <CheckCircle size={16} />
            </div>
          )}
        </div>

        {/* Back of card */}
        <div 
          className={`absolute inset-0 w-full h-full rounded-xl shadow-lg bg-gradient-to-br from-green-500 to-teal-600 text-white flex flex-col justify-center items-center p-6 ${
            isFlipped ? 'opacity-100' : 'opacity-0 rotate-y-180'
          }`}
          style={{ 
            backfaceVisibility: 'hidden',
            transform: isFlipped ? 'rotateY(0deg)' : 'rotateY(-180deg)'
          }}
        >
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-4">{card.back}</h3>
            <div className="flex items-center justify-center space-x-2 text-sm opacity-75">
              <RotateCcw size={16} />
              <span>Click to flip back</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      {showActions && (
        <div className="flex justify-center space-x-4 mt-6">
          <button
            onClick={() => onMarkLearned(card.id, false)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
              card.learned 
                ? 'bg-gray-200 text-gray-600 hover:bg-gray-300' 
                : 'bg-red-100 text-red-700 hover:bg-red-200'
            }`}
          >
            <XCircle size={18} />
            <span>Need Practice</span>
          </button>
          
          <button
            onClick={() => onMarkLearned(card.id, true)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
              card.learned 
                ? 'bg-green-500 text-white hover:bg-green-600' 
                : 'bg-green-100 text-green-700 hover:bg-green-200'
            }`}
          >
            <CheckCircle size={18} />
            <span>Learned</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default Flashcard;