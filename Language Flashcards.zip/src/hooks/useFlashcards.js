// src/hooks/useFlashcards.js
import { useState, useEffect } from 'react';
import { vocabularyData } from '../data/vocabularyData';

export const useFlashcards = () => {
  const [selectedLanguage, setSelectedLanguage] = useState('english');
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [cards, setCards] = useState([]);
  const [learnedCount, setLearnedCount] = useState(0);
  const [studyMode, setStudyMode] = useState('all'); // 'all', 'unlearned', 'learned'

  // Initialize cards when language changes
  useEffect(() => {
    const languageCards = vocabularyData[selectedLanguage] || [];
    setCards(languageCards);
    setCurrentCardIndex(0);
    setIsFlipped(false);
    updateLearnedCount(languageCards);
  }, [selectedLanguage]);

  // Filter cards based on study mode
  const filteredCards = cards.filter(card => {
    switch (studyMode) {
      case 'learned':
        return card.learned;
      case 'unlearned':
        return !card.learned;
      default:
        return true;
    }
  });

  const currentCard = filteredCards[currentCardIndex];

  const updateLearnedCount = (cardList) => {
    const learned = cardList.filter(card => card.learned).length;
    setLearnedCount(learned);
  };

  const nextCard = () => {
    if (filteredCards.length > 0) {
      setCurrentCardIndex((prev) => (prev + 1) % filteredCards.length);
      setIsFlipped(false);
    }
  };

  const prevCard = () => {
    if (filteredCards.length > 0) {
      setCurrentCardIndex((prev) => (prev - 1 + filteredCards.length) % filteredCards.length);
      setIsFlipped(false);
    }
  };

  const flipCard = () => {
    setIsFlipped(!isFlipped);
  };

  const markAsLearned = (cardId, learned = true) => {
    const updatedCards = cards.map(card =>
      card.id === cardId ? { ...card, learned } : card
    );
    setCards(updatedCards);
    updateLearnedCount(updatedCards);

    // Update the original data source
    vocabularyData[selectedLanguage] = updatedCards;
  };

  const resetProgress = () => {
    const resetCards = cards.map(card => ({ ...card, learned: false }));
    setCards(resetCards);
    updateLearnedCount(resetCards);
    vocabularyData[selectedLanguage] = resetCards;
  };

  const shuffleCards = () => {
    const shuffled = [...cards].sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setCurrentCardIndex(0);
    setIsFlipped(false);
  };

  // Update study mode and reset card index
  const setStudyModeWithReset = (mode) => {
    setStudyMode(mode);
    setCurrentCardIndex(0);
    setIsFlipped(false);
  };

  return {
    selectedLanguage,
    setSelectedLanguage,
    currentCard,
    currentCardIndex,
    totalCards: filteredCards.length,
    allCards: cards.length,
    isFlipped,
    learnedCount,
    studyMode,
    setStudyMode: setStudyModeWithReset,
    nextCard,
    prevCard,
    flipCard,
    markAsLearned,
    resetProgress,
    shuffleCards,
    progress: cards.length > 0 ? Math.round((learnedCount / cards.length) * 100) : 0,
    cards // Return the cards array for StatsPanel
  };
};