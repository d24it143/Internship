// src/utils/spacedRepetition.js

// Spaced repetition algorithm based on SM-2 (SuperMemo 2)
export class SpacedRepetition {
  constructor() {
    this.minEaseFactor = 1.3;
    this.defaultEaseFactor = 2.5;
  }

  // Calculate next review date based on performance
  calculateNextReview(card, quality) {
    // quality: 0-5 scale
    // 0-2: incorrect response
    // 3-5: correct response (3=barely, 4=good, 5=perfect)
    
    const now = new Date();
    let { easeFactor = this.defaultEaseFactor, interval = 1, repetition = 0 } = card;

    if (quality >= 3) {
      // Correct response
      if (repetition === 0) {
        interval = 1;
      } else if (repetition === 1) {
        interval = 6;
      } else {
        interval = Math.round(interval * easeFactor);
      }
      repetition += 1;
    } else {
      // Incorrect response - reset repetition
      repetition = 0;
      interval = 1;
    }

    // Update ease factor
    easeFactor = easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
    easeFactor = Math.max(easeFactor, this.minEaseFactor);

    // Calculate next review date
    const nextReview = new Date(now.getTime() + interval * 24 * 60 * 60 * 1000);

    return {
      easeFactor,
      interval,
      repetition,
      nextReview,
      lastReviewed: now
    };
  }

  // Check if card is due for review
  isDue(card) {
    if (!card.nextReview) return true;
    return new Date() >= new Date(card.nextReview);
  }

  // Get cards that are due for review
  getDueCards(cards) {
    return cards.filter(card => this.isDue(card));
  }

  // Sort cards by priority (overdue cards first, then by difficulty)
  sortCardsByPriority(cards) {
    const now = new Date();
    return cards.sort((a, b) => {
      // Check if cards are overdue
      const aOverdue = a.nextReview && now > new Date(a.nextReview);
      const bOverdue = b.nextReview && now > new Date(b.nextReview);

      if (aOverdue && !bOverdue) return -1;
      if (!aOverdue && bOverdue) return 1;

      // If both overdue or both not overdue, sort by difficulty
      const difficultyWeight = { easy: 1, medium: 2, hard: 3 };
      return difficultyWeight[b.difficulty] - difficultyWeight[a.difficulty];
    });
  }

  // Get study statistics
  getStudyStats(cards) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today.getTime() + 24 * 60 * 60 * 1000);

    const stats = {
      total: cards.length,
      new: cards.filter(card => !card.lastReviewed).length,
      learning: cards.filter(card => card.repetition > 0 && card.repetition < 3).length,
      review: cards.filter(card => card.repetition >= 3).length,
      dueToday: cards.filter(card => 
        !card.nextReview || new Date(card.nextReview) <= tomorrow
      ).length,
      overdue: cards.filter(card => 
        card.nextReview && new Date(card.nextReview) < today
      ).length
    };

    return stats;
  }

  // Generate study session with optimal card selection
  generateStudySession(cards, sessionSize = 20) {
    const dueCards = this.getDueCards(cards);
    const prioritizedCards = this.sortCardsByPriority(dueCards);
    
    return prioritizedCards.slice(0, sessionSize);
  }
}