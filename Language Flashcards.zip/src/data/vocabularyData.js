// src/data/vocabularyData.js
export const vocabularyData = {
  english: [
    { id: 1, front: "Hello", back: "A greeting", difficulty: "easy", learned: false },
    { id: 2, front: "Beautiful", back: "Having beauty; pleasing to the senses", difficulty: "medium", learned: false },
    { id: 3, front: "Serendipity", back: "The occurrence of events by chance in a happy way", difficulty: "hard", learned: false },
    { id: 4, front: "Knowledge", back: "Information and skills acquired through experience", difficulty: "medium", learned: false },
    { id: 5, front: "Journey", back: "An act of traveling from one place to another", difficulty: "easy", learned: false },
    { id: 6, front: "Perseverance", back: "Persistence in doing something despite difficulty", difficulty: "hard", learned: false },
    { id: 7, front: "Wisdom", back: "The quality of having experience and good judgment", difficulty: "medium", learned: false },
    { id: 8, front: "Adventure", back: "An unusual and exciting experience", difficulty: "easy", learned: false },
    { id: 9, front: "Magnificent", back: "Extremely beautiful, elaborate, or impressive", difficulty: "medium", learned: false },
    { id: 10, front: "Resilience", back: "The ability to recover quickly from difficulties", difficulty: "hard", learned: false }
  ],
  spanish: [
    { id: 1, front: "Hola", back: "Hello - A greeting", difficulty: "easy", learned: false },
    { id: 2, front: "Hermoso", back: "Beautiful - Having beauty", difficulty: "medium", learned: false },
    { id: 3, front: "Serendipia", back: "Serendipity - Happy accident", difficulty: "hard", learned: false },
    { id: 4, front: "Conocimiento", back: "Knowledge - Information and skills", difficulty: "medium", learned: false },
    { id: 5, front: "Viaje", back: "Journey - Act of traveling", difficulty: "easy", learned: false },
    { id: 6, front: "Perseverancia", back: "Perseverance - Persistence despite difficulty", difficulty: "hard", learned: false },
    { id: 7, front: "Sabiduría", back: "Wisdom - Quality of good judgment", difficulty: "medium", learned: false },
    { id: 8, front: "Aventura", back: "Adventure - Exciting experience", difficulty: "easy", learned: false },
    { id: 9, front: "Magnífico", back: "Magnificent - Extremely impressive", difficulty: "medium", learned: false },
    { id: 10, front: "Resistencia", back: "Resilience - Ability to recover from difficulties", difficulty: "hard", learned: false }
  ],
  french: [
    { id: 1, front: "Bonjour", back: "Hello - A greeting", difficulty: "easy", learned: false },
    { id: 2, front: "Beau", back: "Beautiful - Having beauty", difficulty: "medium", learned: false },
    { id: 3, front: "Sérendipité", back: "Serendipity - Happy coincidence", difficulty: "hard", learned: false },
    { id: 4, front: "Connaissance", back: "Knowledge - Information and skills", difficulty: "medium", learned: false },
    { id: 5, front: "Voyage", back: "Journey - Act of traveling", difficulty: "easy", learned: false },
    { id: 6, front: "Persévérance", back: "Perseverance - Persistence despite difficulty", difficulty: "hard", learned: false },
    { id: 7, front: "Sagesse", back: "Wisdom - Quality of good judgment", difficulty: "medium", learned: false },
    { id: 8, front: "Aventure", back: "Adventure - Exciting experience", difficulty: "easy", learned: false },
    { id: 9, front: "Magnifique", back: "Magnificent - Extremely impressive", difficulty: "medium", learned: false },
    { id: 10, front: "Résilience", back: "Resilience - Ability to recover from difficulties", difficulty: "hard", learned: false }
  ],
  german: [
    { id: 1, front: "Hallo", back: "Hello - A greeting", difficulty: "easy", learned: false },
    { id: 2, front: "Schön", back: "Beautiful - Having beauty", difficulty: "medium", learned: false },
    { id: 3, front: "Serendipität", back: "Serendipity - Happy accident", difficulty: "hard", learned: false },
    { id: 4, front: "Wissen", back: "Knowledge - Information and skills", difficulty: "medium", learned: false },
    { id: 5, front: "Reise", back: "Journey - Act of traveling", difficulty: "easy", learned: false },
    { id: 6, front: "Ausdauer", back: "Perseverance - Persistence despite difficulty", difficulty: "hard", learned: false },
    { id: 7, front: "Weisheit", back: "Wisdom - Quality of good judgment", difficulty: "medium", learned: false },
    { id: 8, front: "Abenteuer", back: "Adventure - Exciting experience", difficulty: "easy", learned: false },
    { id: 9, front: "Großartig", back: "Magnificent - Extremely impressive", difficulty: "medium", learned: false },
    { id: 10, front: "Widerstandsfähigkeit", back: "Resilience - Ability to recover from difficulties", difficulty: "hard", learned: false }
  ]
};