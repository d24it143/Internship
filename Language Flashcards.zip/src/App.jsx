// src/App.jsx
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Shuffle, RotateCcw, Settings, BarChart3 } from 'lucide-react';
import { useFlashcards } from './hooks/useFlashcards';
import Flashcard from './components/Flashcard';
import LanguageSelector from './components/LanguageSelector';
import ProgressBar from './components/ProgressBar';
import StatsPanel from './components/StatsPanel';
import './App.css';

function App() {
  const {
    selectedLanguage,
    setSelectedLanguage,
    currentCard,
    currentCardIndex,
    totalCards,
    allCards,
    isFlipped,
    learnedCount,
    studyMode,
    setStudyMode,
    nextCard,
    prevCard,
    flipCard,
    markAsLearned,
    resetProgress,
    shuffleCards,
    progress,
    cards // Add this to get all cards for StatsPanel
  } = useFlashcards();

  const [showStats, setShowStats] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const availableLanguages = ['english', 'spanish', 'french', 'german'];

  const studyModes = [
    { value: 'all', label: 'All Cards', icon: '📚' },
    { value: 'unlearned', label: 'Need Practice', icon: '🎯' },
    { value: 'learned', label: 'Learned', icon: '✅' }
  ];

  // Add keyboard event listener
  React.useEffect(() => {
    const handleKeyPress = (event) => {
      switch (event.key) {
        case ' ':
          event.preventDefault();
          flipCard();
          break;
        case 'ArrowRight':
          nextCard();
          break;
        case 'ArrowLeft':
          prevCard();
          break;
        case 'r':
        case 'R':
          resetProgress();
          break;
        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [flipCard, nextCard, prevCard, resetProgress]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            🎓 Language Flashcards
          </h1>
          <p className="text-gray-600">Master vocabulary with interactive flashcards</p>
        </header>

        {/* Control Panel */}
        <div className="max-w-6xl mx-auto mb-8">
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <div className="flex flex-col lg:flex-row items-center justify-between space-y-4 lg:space-y-0 lg:space-x-6">
              {/* Language Selector */}
              <div className="w-full lg:w-auto">
                <LanguageSelector
                  selectedLanguage={selectedLanguage}
                  onLanguageChange={setSelectedLanguage}
                  languages={availableLanguages}
                />
              </div>

              {/* Study Mode Selector */}
              <div className="w-full lg:w-auto">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Study Mode
                </label>
                <div className="flex space-x-2">
                  {studyModes.map((mode) => (
                    <button
                      key={mode.value}
                      onClick={() => setStudyMode(mode.value)}
                      className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                        studyMode === mode.value
                          ? 'bg-blue-500 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      <span>{mode.icon}</span>
                      <span className="hidden sm:inline">{mode.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-2">
                <button
                  onClick={() => setShowStats(!showStats)}
                  className="flex items-center space-x-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors"
                >
                  <BarChart3 size={18} />
                  <span className="hidden sm:inline">Stats</span>
                </button>
                
                <button
                  onClick={() => setShowSettings(!showSettings)}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <Settings size={18} />
                  <span className="hidden sm:inline">Settings</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Settings Panel */}
        {showSettings && (
          <div className="max-w-6xl mx-auto mb-8">
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Settings</h3>
              <div className="flex flex-wrap gap-4">
                <button
                  onClick={shuffleCards}
                  className="flex items-center space-x-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
                >
                  <Shuffle size={18} />
                  <span>Shuffle Cards</span>
                </button>
                
                <button
                  onClick={resetProgress}
                  className="flex items-center space-x-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
                >
                  <RotateCcw size={18} />
                  <span>Reset Progress</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Stats Panel */}
        {showStats && (
          <div className="max-w-6xl mx-auto mb-8">
            <StatsPanel
              cards={cards || []}
              learnedCount={learnedCount}
              progress={progress}
              selectedLanguage={selectedLanguage}
            />
          </div>
        )}

        {/* Main Content */}
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Progress Bar */}
            <div className="lg:col-span-1">
              <ProgressBar
                progress={progress}
                learnedCount={learnedCount}
                totalCards={allCards}
                currentCardIndex={currentCardIndex}
              />
            </div>

            {/* Flashcard Area */}
            <div className="lg:col-span-2">
              <div className="text-center mb-6">
                <div className="flex items-center justify-center space-x-4 mb-4">
                  <span className="text-sm text-gray-600">
                    Card {currentCardIndex + 1} of {totalCards}
                  </span>
                  <span className="text-sm text-gray-600">
                    ({studyMode === 'all' ? 'All Cards' : 
                      studyMode === 'learned' ? 'Learned Cards' : 'Need Practice'})
                  </span>
                </div>
              </div>

              {/* Flashcard */}
              {currentCard ? (
                <Flashcard
                  card={currentCard}
                  isFlipped={isFlipped}
                  onFlip={flipCard}
                  onMarkLearned={markAsLearned}
                />
              ) : (
                <div className="w-full max-w-md mx-auto bg-gray-100 rounded-xl p-8 text-center text-gray-500">
                  No cards available for this study mode
                </div>
              )}

              {/* Navigation */}
              <div className="flex justify-center items-center space-x-4 mt-8">
                <button
                  onClick={prevCard}
                  disabled={totalCards === 0}
                  className="flex items-center space-x-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft size={20} />
                  <span>Previous</span>
                </button>

                <div className="text-sm text-gray-500">
                  {totalCards > 0 ? `${currentCardIndex + 1} / ${totalCards}` : 'No cards'}
                </div>

                <button
                  onClick={nextCard}
                  disabled={totalCards === 0}
                  className="flex items-center space-x-2 px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <span>Next</span>
                  <ChevronRight size={20} />
                </button>
              </div>

              {/* Keyboard Shortcuts Info */}
              <div className="mt-8 p-4 bg-gray-50 rounded-lg">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Keyboard Shortcuts:</h4>
                <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
                  <div>• Space: Flip card</div>
                  <div>• →: Next card</div>
                  <div>• ←: Previous card</div>
                  <div>• R: Reset progress</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="text-center mt-12 text-gray-500 text-sm">
          <p>Practice makes perfect! Keep learning and stay motivated! 🌟</p>
        </footer>
      </div>
    </div>
  );
}

export default App;